#!/bin/bash
# Network Scanner installer: copies the app to /Applications and launches it.
cd "$(dirname "$0")"
echo "Installing Network Scanner…"
pkill -x NetworkScanner 2>/dev/null; sleep 0.5
rm -rf /Applications/NetworkScanner.app
ditto --norsrc NetworkScanner.app /Applications/NetworkScanner.app
# Clear the download quarantine and re-sign locally so macOS trusts it on this Mac.
xattr -dr com.apple.quarantine /Applications/NetworkScanner.app 2>/dev/null
codesign --force --sign - /Applications/NetworkScanner.app
tccutil reset All com.jonpike.networkscanner >/dev/null 2>&1
open /Applications/NetworkScanner.app
echo
echo "Done! Network Scanner is in your Applications folder."
echo "Allow Local Network access when macOS asks, or scans will find nothing."
