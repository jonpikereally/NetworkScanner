Network Scanner v1.1 (build 8): see what's on your network, for macOS 14+
https://github.com/jonpikereally/NetworkScanner

INSTALL
1. Double-click "Install Network Scanner.command".
   If macOS blocks it: right-click it, choose Open, then Open again.
2. Allow Local Network access when macOS asks (System Settings → Privacy & Security →
   Local Network). Without it, scans find nothing.

USE
• Open Network Scanner from Applications. It scans when it opens; ⌘R rescans.
• Select a device to see its details; Deep Scan checks about 1,100 ports on it.
• Devices new since the last scan are marked NEW. Double-click a device to name it.
• Right-click a device to copy its address or open its web page.

PRIVACY
Scans stay on your network. Network Scanner fetches two things from the internet: a small
version file from the GitHub repo above (to see whether an update exists), and, unless you
turn off "Look Up Device Makers", the public MAC maker list from wireshark.org once a month.
